"""
    Ref: https://www.kaggle.com/c/tgs-salt-identification-challenge/discussion/65938
    https://discuss.pytorch.org/t/focal-loss-for-imbalanced-multi-class-classification-in-pytorch/61289
 """
import torch
import torch.nn as nn

class FocalLoss(nn.Module):
    def __init__(self, alpha=1, gamma=2, reduce=True):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduce = reduce

    def forward(self, inputs, targets, weight=None):
        BCE_loss = nn.functional.binary_cross_entropy(inputs, targets, weight, reduction='mean')
        pt = torch.exp(-BCE_loss)
        F_loss = self.alpha * (1-pt)**self.gamma * BCE_loss
        # mean over the batch
        return torch.mean(F_loss)

"""
Reference: https://github.com/pytorch/pytorch/issues/1249#issuecomment-305088398
"""
class DiceLoss(nn.Module):
    def __init__(self, smooth=1):
        super().__init__()
        self.smooth = smooth

    def forward(self, inputs, targets):
        # Flatten both input and GT tensors
        iflat = inputs.view(-1)
        tflat = targets.view(-1)

        # Compute dice loss
        intersection = (iflat * tflat).sum()
        return 1 - ((2. * intersection + self.smooth) /
                (iflat.sum() + tflat.sum() + self.smooth))